package e02_Blobs.interfaces;

public interface Behaviour {

    void trigger(Blob blob);

    void updateStats(Blob blob);
}
