package e02_Blobs.interfaces;

public interface InputReader {

    String readLine();
}
