package e02_Blobs.interfaces;

public interface Attack {

    void executeAttack(Blob attacker, Blob target);
}
