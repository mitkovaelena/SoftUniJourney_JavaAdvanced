package e02_Blobs.interfaces;

public interface OutputWriter {

    void writeLine(String output);

    void write(String output);
}
