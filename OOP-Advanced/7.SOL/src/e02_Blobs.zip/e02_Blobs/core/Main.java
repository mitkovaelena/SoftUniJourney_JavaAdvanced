package e02_Blobs.core;

public class Main {
    public static void main(String[] args) {
        Engine engine = new Engine();
        engine.run();
    }
}
