package app.logger;

/**
 * Created by Venelin on 12.4.2017 г..
 */
public enum LogType {
    ATTACK, MAGIC, ERROR, EVENT, TARGET;
}
