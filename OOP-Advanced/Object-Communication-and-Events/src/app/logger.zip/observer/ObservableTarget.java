package app.observer;

import app.models.Target;

/**
 * Created by Venelin on 12.4.2017 г..
 */
public interface ObservableTarget extends Target, Subject {
}
