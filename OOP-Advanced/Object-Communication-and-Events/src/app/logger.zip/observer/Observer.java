package app.observer;

/**
 * Created by Venelin on 12.4.2017 г..
 */
public interface Observer {

    void update(int reward);
}
