package kingsGambit;

/**
 * Created by Venelin on 13.4.2017 г..
 */
public interface Defender {

    void respond();

    String getDefenderName();
}
