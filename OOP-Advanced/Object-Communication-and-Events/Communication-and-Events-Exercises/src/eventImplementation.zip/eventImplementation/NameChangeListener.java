package eventImplementation;

/**
 * Created by Venelin on 12.4.2017 г..
 */
public interface NameChangeListener {

    void handleChangedName(NameChange event);
}
