package eventImplementation;

/**
 * Created by Venelin on 12.4.2017 г..
 */
public class NameChange {

    private String changedName;

    public NameChange(String changedName) {
        this.changedName = changedName;
    }

    public String getChangedName() {
        return changedName;
    }
}
