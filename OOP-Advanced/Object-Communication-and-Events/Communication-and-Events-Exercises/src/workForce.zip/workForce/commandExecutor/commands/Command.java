package workForce.commandExecutor.commands;

/**
 * Created by Venelin on 14.4.2017 г..
 */
public interface Command {

    void execute();
}
