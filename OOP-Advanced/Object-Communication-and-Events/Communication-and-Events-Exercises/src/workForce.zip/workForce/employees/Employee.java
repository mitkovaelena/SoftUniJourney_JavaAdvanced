package workForce.employees;

/**
 * Created by Venelin on 15.4.2017 г..
 */
public interface Employee {

    String getName();

    int getWorkHoursPerWeek();
}
