package dependencyInversionSkeleton.strategies;

/**
 * Created by Dani on 14.4.2017 г..
 */
public interface Strategy {

    int calculate(int firstOperand, int secondOperand);
}
